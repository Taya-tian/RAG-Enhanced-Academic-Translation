"""
RAG knowledge base from CN–EN / EN–CN translation Excel files.
Builds an index once, then for each source file from the command line: query and write <stem>context.txt.
Usage: python knowledge_base.py [file1.txt file2.txt ...]
       If no files given, defaults to text1.txt in data/.
"""
import sys
from pathlib import Path
from typing import List

import pandas as pd

from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core import VectorStoreIndex, Settings
from llama_index.core.schema import Document
from llama_index.core.retrievers import VectorIndexRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.postprocessor import SimilarityPostprocessor
from llama_index.core.postprocessor.types import BaseNodePostprocessor

# Optional: LLM reranker for better ordering of retrieved nodes (set USE_LLM_RERANK=True and Settings.llm)
try:
    from llama_index.core.postprocessor import LLMRerank
except ImportError:
    LLMRerank = None  # type: ignore[misc, assignment]

# --- Paths (Excel columns 6 & 7 = 0-based indices 5 & 6) ---
DATA_DIR = Path(__file__).resolve().parent / "data"
CN_EN_PATH = DATA_DIR / "cn-en.xlsx"
EN_CN_PATH = DATA_DIR / "en-cn.xlsx"
TEXT1_PATH = DATA_DIR / "text1.txt"

# Column indices: 6th and 7th column -> 5 and 6 (0-based)
COL_SOURCE = 5
COL_TARGET = 6

# --- Retrieval settings (tune these for more accurate results) ---
# How many translation pairs to retrieve for the prompt. Higher = more context, more noise.
TOP_K = 10
# Minimum similarity score (0–1). Raise to filter out weak matches (e.g. 0.5–0.7).
SIMILARITY_CUTOFF = 0.4
# Use an LLM to rerank retrieved nodes (better order, higher cost/latency). Set to True and set Settings.llm to enable.
USE_LLM_RERANK = False

# --- What affects retrieval accuracy ---
# • Embedding model (Settings.embed_model): better CN/EN model = better similarity (e.g. BAAI/bge-m3).
# • TOP_K: larger = more references, but can add noise; tune for your glossary size.
# • SIMILARITY_CUTOFF: higher (e.g. 0.5–0.7) = stricter, fewer but more relevant results.
# • USE_LLM_RERANK: True + Settings.llm set = two-stage retrieval (embedding recall + LLM rerank) for better ordering.
# • Chunking: each row is one “chunk” here; no chunk_size/overlap effect on index, but embed model’s max length still applies.
# An LLM in this script is optional: only needed for reranking. Final translation is still done by you in ChatGPT.


def load_translation_documents() -> list[Document]:
    """Load cn-en.xlsx and en-cn.xlsx; columns 6 & 7 are source/target. Return LlamaIndex Documents."""
    documents: list[Document] = []

    # cn-en.xlsx: col6 = CN, col7 = EN
    if CN_EN_PATH.exists():
        df_cn_en = pd.read_excel(CN_EN_PATH, header=None, engine="openpyxl")
        for i, row in df_cn_en.iterrows():
            cn = _cell_str(row, COL_SOURCE)
            en = _cell_str(row, COL_TARGET)
            if cn or en:
                text = f"Chinese: {cn}\nEnglish: {en}"
                documents.append(Document(text=text, metadata={"source": "cn-en", "row": str(i)}))

    # en-cn.xlsx: col6 = EN, col7 = CN
    if EN_CN_PATH.exists():
        df_en_cn = pd.read_excel(EN_CN_PATH, header=None, engine="openpyxl")
        for i, row in df_en_cn.iterrows():
            en = _cell_str(row, COL_SOURCE)
            cn = _cell_str(row, COL_TARGET)
            if cn or en:
                text = f"Chinese: {cn}\nEnglish: {en}"
                documents.append(Document(text=text, metadata={"source": "en-cn", "row": str(i)}))

    return documents


def _cell_str(row: pd.Series, col: int) -> str:
    if col >= len(row):
        return ""
    v = row.iloc[col]
    if pd.isna(v):
        return ""
    return str(v).strip()


def read_chinese_from_txt(path: Path) -> str:
    """Read Chinese text from a .txt file (UTF-8)."""
    return path.read_text(encoding="utf-8").strip()


def build_prompt(chinese_text: str, nodes: List) -> str:
    """Build the ChatGPT prompt from retrieved nodes and Chinese text."""
    reference_block = "Reference translations (from glossary):\n"
    for i, node in enumerate(nodes, 1):
        score = getattr(node, "score", None)
        score_str = f" [similarity: {float(score):.3f}]" if score is not None else ""
        reference_block += f"{i}.{score_str} {node.text}\n"
    return f"""{reference_block}

Chinese text to translate:
---
{chinese_text}
---

Using the reference translations above for terminology and style, provide the best English translation of the Chinese text. 
please give the reference in the translation result and write the whole result into a download text file
"""


def main() -> None:
    # Embedding model: BGE-M3 is multilingual (100+ languages), strong on Chinese + English
    Settings.embed_model = HuggingFaceEmbedding(model_name="BAAI/bge-m3")
    Settings.llm = None
    Settings.chunk_size = 512
    Settings.chunk_overlap = 50
    # Avoid "available context size not non-negative" when query text is long (PromptHelper default is 3900)
    Settings.context_window = 8192
    Settings.num_output = 256

    # Load glossary from Excel and build index
    documents = load_translation_documents()
    if not documents:
        raise SystemExit("No documents loaded from cn-en.xlsx and en-cn.xlsx. Check paths and column indices.")

    print(f"Loaded {len(documents)} translation pairs from Excel.")

    index = VectorStoreIndex.from_documents(documents)
    # Retrieve more candidates if using reranker, then cut down
    retriever_top_k = TOP_K * 3 if USE_LLM_RERANK else TOP_K
    retriever = VectorIndexRetriever(index=index, similarity_top_k=retriever_top_k)
    node_postprocessors: List[BaseNodePostprocessor] = [
        SimilarityPostprocessor(similarity_cutoff=SIMILARITY_CUTOFF),
    ]
    if USE_LLM_RERANK and LLMRerank is not None and Settings.llm is not None:
        node_postprocessors.append(LLMRerank(llm=Settings.llm, top_n=TOP_K))  # type: ignore[arg-type]
    query_engine = RetrieverQueryEngine(
        retriever=retriever,
        node_postprocessors=node_postprocessors,
    )

    # Source files: from command line, or default to text1.txt
    if len(sys.argv) > 1:
        source_names = [a.strip() for a in sys.argv[1:] if a.strip()]
    else:
        source_names = [TEXT1_PATH.name]

    if not source_names:
        raise SystemExit("No source files given. Usage: python knowledge_base.py [file1.txt file2.txt ...]")

    # Resolve paths under DATA_DIR
    source_paths: List[Path] = []
    for name in source_names:
        p = Path(name)
        if not p.is_absolute():
            p = DATA_DIR / p.name
        source_paths.append(p)

    # Process each source file: query only (index already built), write context file
    single = len(source_paths) == 1
    for src_path in source_paths:
        if not src_path.exists():
            print(f"Skip (not found): {src_path}")
            continue
        chinese_text = read_chinese_from_txt(src_path)
        if not chinese_text:
            print(f"Skip (empty): {src_path}")
            continue

        response = query_engine.query(chinese_text)
        nodes = response.source_nodes[:TOP_K]
        prompt = build_prompt(chinese_text, nodes)

        output_path = DATA_DIR / f"{src_path.stem}_context.txt"
        output_path.write_text(prompt, encoding="utf-8")
        print(f"Result written to: {output_path}")

        if single:
            print("\n--- Query results (similarity) ---")
            for i, node in enumerate(nodes, 1):
                score = getattr(node, "score", None)
                score_str = f"{float(score):.4f}" if score is not None else "N/A"
                preview = (node.text[:80] + "…") if len(node.text) > 80 else node.text
                print(f"  {i}. similarity = {score_str}  {preview}")
            print("\n" + "=" * 60)
            print("PROMPT FOR CHATGPT (copy and paste):")
            print("=" * 60)
            print(prompt)
            print("=" * 60)


if __name__ == "__main__":
    main()